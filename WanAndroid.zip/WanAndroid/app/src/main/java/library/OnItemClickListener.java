package library;


public interface OnItemClickListener {
    public void onItemClick(int position);
}
