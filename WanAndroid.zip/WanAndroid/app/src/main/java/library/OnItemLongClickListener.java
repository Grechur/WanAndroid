package library;


public interface OnItemLongClickListener {
    public boolean onLongClick(int position);
}
