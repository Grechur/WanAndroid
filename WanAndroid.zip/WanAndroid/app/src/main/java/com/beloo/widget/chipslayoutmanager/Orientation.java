package com.beloo.widget.chipslayoutmanager;

public interface Orientation {
}
