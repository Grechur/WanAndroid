package com.grechur.wanandroid.model;

/**
 * Created by Chris on 2017/11/30.
 */

public class BaseRequest {
    public String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
