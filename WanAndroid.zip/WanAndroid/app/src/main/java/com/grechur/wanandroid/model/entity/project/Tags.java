package com.grechur.wanandroid.model.entity.project;

/**
 * Created by zz on 2018/5/25.
 */

public class Tags {
    public String name;
    public String url;
}
