package com.grechur.wanandroid.model.entity.navigation;

import com.grechur.wanandroid.model.entity.Article;

import java.util.List;

/**
 * Created by zz on 2018/5/24.
 */
public class NaviArticle {
    public List<Article> articles;
    public int cid;
    public String name;
}
