package com.grechur.wanandroid.view;


public interface OnItemLongClickListener {
    public boolean onLongClick(int position);
}
