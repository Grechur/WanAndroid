package com.grechur.wanandroid.model.entity.project;

import java.util.List;

/**
 * Created by zz on 2018/5/25.
 */

public class ProjectData {
    public int curPage;
    public List<ProjectInfo> datas;
    public int offset;
    public boolean over;
    public int pageCount;
    public int size;
    public int total;
}
