package com.grechur.wanandroid.view;


import android.view.View;

public interface OnItemClickListener {
     void onItemClick(View view, int position);
}
