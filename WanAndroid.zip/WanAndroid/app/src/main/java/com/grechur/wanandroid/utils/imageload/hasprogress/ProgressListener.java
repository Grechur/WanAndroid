package com.grechur.wanandroid.utils.imageload.hasprogress;

/**
 * Created by zz on 2018/8/20.
 */

public interface ProgressListener {
    void onProgress(long currentByte,long countByte);
}
