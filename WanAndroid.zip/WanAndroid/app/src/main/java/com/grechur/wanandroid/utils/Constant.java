package com.grechur.wanandroid.utils;

/**
 * Created by zz on 2018/5/24.
 */

public class Constant {
    public static final String INTENT_ID = "intent_id";

    public static final String INTENT_URL = "intent_url";
    public static final String INTENT_PID = "intent_pid";

    public static final String INTENT_TITLE = "intent_title";

    public static final String INTENT_KEY = "intent_key";


}
