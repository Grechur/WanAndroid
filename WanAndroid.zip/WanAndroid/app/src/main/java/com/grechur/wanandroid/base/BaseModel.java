package com.grechur.wanandroid.base;

/**
 * Created by zz on 2018/5/22.
 */

public interface BaseModel {
}
