package com.grechur.wanandroid.api;

/**
 * @ClassName: User
 * @Description: java类作用描述
 * @Author: Grechur
 * @Date: 2019/8/30 11:32
 */
public class User {
}